// dictionary_bloc.dart
import 'package:bloc/bloc.dart';
import '../database/database_helper.dart';
import '../models/word.dart';
import 'dictionary_event.dart';
import 'dictionary_state.dart';

class DictionaryBloc extends Bloc<DictionaryEvent, DictionaryState> {
  final DatabaseHelper dbHelper = DatabaseHelper();
  List<Word> _words = [];
  List<Word> _favoriteWords = [];

  DictionaryBloc() : super(DictionaryLoadingState()) {
    on<LoadWordsEvent>(_loadWords);
    on<AddWordEvent>(_addWord);
    on<EditWordEvent>(_editWord);
    on<DeleteWordEvent>(_deleteWord);
    on<ToggleFavoriteEvent>(_toggleFavorite);
  }

  Future<void> _loadWords(LoadWordsEvent event, Emitter<DictionaryState> emit) async {
    emit(DictionaryLoadingState());
    try {
      final allWords = await dbHelper.getWords();
      _words = allWords;
      _favoriteWords = allWords.where((word) => word.isFavorite).toList();
      emit(DictionaryLoadedState(words: _words, favoriteWords: _favoriteWords));
    } catch (e) {
      emit(DictionaryErrorState('Ошибка загрузки слов: $e'));
    }
  }

  Future<void> _addWord(AddWordEvent event, Emitter<DictionaryState> emit) async {
    await dbHelper.insertWord(event.word);
    add(LoadWordsEvent());
  }

  Future<void> _editWord(EditWordEvent event, Emitter<DictionaryState> emit) async {
    await dbHelper.updateWord(event.word);
    add(LoadWordsEvent());
  }

  Future<void> _deleteWord(DeleteWordEvent event, Emitter<DictionaryState> emit) async {
    await dbHelper.deleteWord(event.id);
    add(LoadWordsEvent());
  }

  Future<void> _toggleFavorite(ToggleFavoriteEvent event, Emitter<DictionaryState> emit) async {
    final updatedWord = Word(
      id: event.word.id,
      word: event.word.word,
      translation: event.word.translation,
      category: event.word.category,
      isFavorite: !event.word.isFavorite,
    );
    await dbHelper.updateWord(updatedWord);
    add(LoadWordsEvent());
  }
}