import 'package:equatable/equatable.dart';
import '../../models/word.dart'; // Add this import

abstract class DictionaryState extends Equatable {
  const DictionaryState();
}

class DictionaryLoadingState extends DictionaryState {
  @override
  List<Object?> get props => [];
}

class DictionaryLoadedState extends DictionaryState {
  final List<Word> words; // Now 'Word' is recognized
  final List<Word> favoriteWords; // Now 'Word' is recognized
  const DictionaryLoadedState({required this.words, required this.favoriteWords});

  @override
  List<Object?> get props => [words, favoriteWords];
}

class DictionaryErrorState extends DictionaryState {
  final String message;
  const DictionaryErrorState(this.message);

  @override
  List<Object?> get props => [message];
}