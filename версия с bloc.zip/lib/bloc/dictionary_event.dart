import 'package:equatable/equatable.dart';
import '../../models/word.dart'; // Add this import

abstract class DictionaryEvent extends Equatable {
  const DictionaryEvent();
}

class LoadWordsEvent extends DictionaryEvent {
  @override
  List<Object?> get props => [];
}

class AddWordEvent extends DictionaryEvent {
  final Word word; // Now 'Word' is recognized
  const AddWordEvent(this.word);

  @override
  List<Object?> get props => [word];
}

class EditWordEvent extends DictionaryEvent {
  final Word word; // Now 'Word' is recognized
  const EditWordEvent(this.word);

  @override
  List<Object?> get props => [word];
}

class DeleteWordEvent extends DictionaryEvent {
  final int id;
  const DeleteWordEvent(this.id);

  @override
  List<Object?> get props => [id];
}

class ToggleFavoriteEvent extends DictionaryEvent {
  final Word word; // Now 'Word' is recognized
  const ToggleFavoriteEvent(this.word);

  @override
  List<Object?> get props => [word];
}