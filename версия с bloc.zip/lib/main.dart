import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'database/database_helper.dart';
import 'bloc/dictionary_bloc.dart';
import 'bloc/dictionary_event.dart';
import 'screens/home_screen.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  // Инициализация sqfliteFfi
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi; // Установка factory для sqflite_common_ffi

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'German Learning App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: BlocProvider(
        create: (context) => DictionaryBloc()..add(LoadWordsEvent()),
        child: HomeScreen(),
      ),
    );
  }
}