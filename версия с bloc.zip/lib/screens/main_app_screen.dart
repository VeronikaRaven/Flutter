import 'package:flutter/material.dart';
import '../bloc/dictionary_bloc.dart'; // Correct path for DictionaryBloc
import '../screens/dictionary_screen.dart'; // Correct path for DictionaryScreen
import '../screens/words_screen.dart'; // Correct path for WordsScreen
import '../screens/tests_screen.dart'; // Correct path for TestsScreen
import '../screens/profile_screen.dart'; // Correct path for ProfileScreen
import '../bloc/dictionary_bloc.dart'; // Import DictionaryBloc
import '../bloc/dictionary_event.dart'; // Import LoadWordsEvent

import 'package:flutter_bloc/flutter_bloc.dart';


class MainAppScreen extends StatelessWidget {
  final String selectedLevel;

  MainAppScreen({required this.selectedLevel});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => DictionaryBloc()..add(LoadWordsEvent()),
      child: DefaultTabController(
        length: 4,
        child: Scaffold(
          appBar: AppBar(
            title: Text('Уровень: $selectedLevel'),
            bottom: TabBar(
              tabs: [
                Tab(text: 'Алфавит'),
                Tab(text: 'Словарь'),
                Tab(text: 'Тесты'),
                Tab(text: 'Профиль'),
              ],
            ),
          ),
          body: TabBarView(
            children: [
              WordsScreen(), // Экран всех слов
              DictionaryScreen(), // Экран словаря
              TestsScreen(), // Экран тестов
              ProfileScreen(), // Экран профиля
            ],
          ),
        ),
      ),
    );
  }
}